# plugin.video.blxdtvcatchup
A basic TV Catchup Add-on for Kodi.

- Author: blxd
- Version: 0.3.2
- Github: https://github.com/blxd/plugin.video.blxdtvcatchup

## Download and Installation

- Simply download [plugin.video.blxdtvcatchup-0.3.2.zip](https://github.com/blxd/plugin.video.blxdtvcatchup/releases/download/v0.3.2/plugin.video.blxdtvcatchup-0.3.2.zip) file and install it in Kodi, you will also need the script.module.xbmcswift2 addon.
- Or install my [repo add-on](https://github.com/blxd/repository.blxd.plugins) and then install the TV Catchup add-on from there.  
